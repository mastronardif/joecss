
function generateTextLeft(where, sentenceCount) {	
	if (1==1) {
		document.write(`		
				<form name = "myform" method="post" action="/cgi-bin/cgi/ngfop/each.cgi">



<!-- <font size="4" color="#FF0000"><b><i>My Schedules</i></b></font>

   -->

<!-- fm 6/18/7 -->

   <i>Welcome Bucci</i><br/>
   
   <form name = "myform" method="POST" action="javascript:go(document.myform.id.value);">

<font size="4" color="#FF0000"><b><i>Pictures</i></b></font>

<br>

&nbsp;&nbsp;Search For:<br>

&nbsp;&nbsp;<input name="id" type=text size=25 name=gg> 

<br>

&nbsp;&nbsp;<input type="button" value="Web! Search" onClick="javascript:go(document.myform.id.value);">

<br>

<i>

<font size="1">

Web images may be subject to copyright.  

</font>

</i>

</form>   

<hr></hr>


   <font size="4" color="#FF0000"><b><i>ABA Programs</i></b></font>

<br>



   &nbsp;&nbsp;

   <a class="menuitem" title="ABA Programs" href="javascript:go33('/cgi-bin/cgi/ngfop/other2.pl?htmlname=myabaframe3.htm');">ABA Programs</a>   

     

   <br>

   &nbsp;&nbsp;

    <a class="menuitem" title="List ABA" href="javascript:go('Pictures');">Edit ABA</a>   

   <br>      

   &nbsp;&nbsp;

   <A HREF="/cgi-bin/cgi/ngfop/other2.pl?htmlname=joepicexchng03.htm&name=cb136168402.xml" TARGET="_blank">Communication Board</A>    

   <br>      

   &nbsp;&nbsp;

   <a class="menuitem" title="My Communication Board" href="javascript:goMyComBoard();">*Edit &nbsp; iCom Board</a>   

<hr></hr> 

<!-- fm 6/18/7 -->

<font size="4" color="#FF0000"><b><i>Schedules by Category</i></b></font>

<br>   

<font size="2" color="#FF0000"><b><i>My Schedules</i></b></font>

<br>



<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch85761475.xml", "0 ABA KIT Academic");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch85761475.xml" TARGET="middle">0 ABA KIT Academic</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch86269408.xml", "0 ABA KIT Not the Demo");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch86269408.xml" TARGET="middle">0 ABA KIT Not the Demo</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch86035240.xml", "0 ABA KIT verbs/occupations/body parts/emotions/places");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch86035240.xml" TARGET="middle">0 ABA KIT verbs/occupations/body parts/emotions/places</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83955016.xml", "0 ABA Kit - Visual Stories");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83955016.xml" TARGET="middle">0 ABA Kit - Visual Stories</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90537026.xml", "0 ABA Kit Christmas");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90537026.xml" TARGET="middle">0 ABA Kit Christmas</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch85768845.xml", "0 ABA Kit Common Objects");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch85768845.xml" TARGET="middle">0 ABA Kit Common Objects</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83949611.xml", "0 ABA Kit Eating/Chores/Homeskills");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83949611.xml" TARGET="middle">0 ABA Kit Eating/Chores/Homeskills</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83935059.xml", "0 ABA Kit Emotions/Feelings");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83935059.xml" TARGET="middle">0 ABA Kit Emotions/Feelings</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch84495762.xml", "0 ABA Kit Halloween Theme");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch84495762.xml" TARGET="middle">0 ABA Kit Halloween Theme</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83949643.xml", "0 ABA Kit Playskills/Recipes");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83949643.xml" TARGET="middle">0 ABA Kit Playskills/Recipes</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90610792.xml", "0 ABA Kit Rooms in House");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90610792.xml" TARGET="middle">0 ABA Kit Rooms in House</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch84462828.xml", "0 ABA Kit Rooms/Emotions/Holidays");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch84462828.xml" TARGET="middle">0 ABA Kit Rooms/Emotions/Holidays</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83938753.xml", "0 ABA Kit Routines/Bathroom/Dressing");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83938753.xml" TARGET="middle">0 ABA Kit Routines/Bathroom/Dressing</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83935270.xml", "0 ABA Kits Occupations");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83935270.xml" TARGET="middle">0 ABA Kits Occupations</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch16903357.xml", "0 After school routine (Add a choice board)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch16903357.xml" TARGET="middle">0 After school routine (Add a choice board)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch16903696.xml", "0 After school routine (Add a chore)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch16903696.xml" TARGET="middle">0 After school routine (Add a chore)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37457499.xml", "0 After school routine (add a social activity )");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37457499.xml" TARGET="middle">0 After school routine (add a social activity )</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch16904827.xml", "0 After school routine (add embedded rewards)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch16904827.xml" TARGET="middle">0 After school routine (add embedded rewards)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch12961949.xml", "0 After school routine (basic)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch12961949.xml" TARGET="middle">0 After school routine (basic)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37455973.xml", "0 After school routine (chore choice board)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37455973.xml" TARGET="middle">0 After school routine (chore choice board)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch16564689.xml", "0 Getting started");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch16564689.xml" TARGET="middle">0 Getting started</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch144620512.xml", "0 Individual Student Schedule");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch144620512.xml" TARGET="middle">0 Individual Student Schedule</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37988453.xml", "0 Morning Routine (Add New Skills)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37988453.xml" TARGET="middle">0 Morning Routine (Add New Skills)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch16801207.xml", "0 Morning Routine (add make your bed)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch16801207.xml" TARGET="middle">0 Morning Routine (add make your bed)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch16800649.xml", "0 Morning Routine (basic)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch16800649.xml" TARGET="middle">0 Morning Routine (basic)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch16800357.xml", "0 Morning Routine (get dressed)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch16800357.xml" TARGET="middle">0 Morning Routine (get dressed)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch16800716.xml", "0 Morning Routine (replace get dressed with a single picture)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch16800716.xml" TARGET="middle">0 Morning Routine (replace get dressed with a single picture)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch16801352.xml", "0 Morning Routine (replace make your bed with a single picture)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch16801352.xml" TARGET="middle">0 Morning Routine (replace make your bed with a single picture)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch148164111.xml", "0 Tyler&#39;s morning");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch148164111.xml" TARGET="middle">0 Tyler&#39;s morning</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch36782529.xml", "00 Bowling");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch36782529.xml" TARGET="middle">00 Bowling</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch31681033.xml", "00 Chore Chart");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch31681033.xml" TARGET="middle">00 Chore Chart</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch31671758.xml", "00 My list of skills I want to teach");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch31671758.xml" TARGET="middle">00 My list of skills I want to teach</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch31764043.xml", "00 My rewards");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch31764043.xml" TARGET="middle">00 My rewards</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch12960076.xml", "00 Night time routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch12960076.xml" TARGET="middle">00 Night time routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37460233.xml", "00 Night time routine (with time)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37460233.xml" TARGET="middle">00 Night time routine (with time)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch13033274.xml", "00 Rule Cards");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch13033274.xml" TARGET="middle">00 Rule Cards</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch12481146.xml", "00 skills checklist");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch12481146.xml" TARGET="middle">00 skills checklist</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch12613526.xml", "00 video schedule");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch12613526.xml" TARGET="middle">00 video schedule</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch93906942.xml", "000 Kit - Kris&#39;s Kit");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch93906942.xml" TARGET="middle">000 Kit - Kris&#39;s Kit</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch93622731.xml", "000 Kit - js 22");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch93622731.xml" TARGET="middle">000 Kit - js 22</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch147913927.xml", "00000000");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch147913927.xml" TARGET="middle">00000000</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch142250046.xml", "0000Class Schedule");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch142250046.xml" TARGET="middle">0000Class Schedule</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch12866061.xml", "01 Pack your lunch");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch12866061.xml" TARGET="middle">01 Pack your lunch</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch12849588.xml", "01 Set the table");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch12849588.xml" TARGET="middle">01 Set the table</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch003.xml", "01 table set");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch003.xml" TARGET="middle">01 table set</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch186765558.xml", "0FindSanta");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch186765558.xml" TARGET="middle">0FindSanta</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17326228.xml", "A A Places");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17326228.xml" TARGET="middle">A A Places</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch130524573.xml", "A Receptive Object Id");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch130524573.xml" TARGET="middle">A Receptive Object Id</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17532564.xml", "Accessories");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17532564.xml" TARGET="middle">Accessories</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17497434.xml", "Actions");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17497434.xml" TARGET="middle">Actions</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch152645697.xml", "Add a time");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch152645697.xml" TARGET="middle">Add a time</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch32027852.xml", "Add a time 2");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch32027852.xml" TARGET="middle">Add a time 2</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37926564.xml", "Add more skills");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37926564.xml" TARGET="middle">Add more skills</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch8205860.xml", "After school");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch8205860.xml" TARGET="middle">After school</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch32370570.xml", "After school routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch32370570.xml" TARGET="middle">After school routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37921429.xml", "After school snacks2");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37921429.xml" TARGET="middle">After school snacks2</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch15703831.xml", "Afternoon Routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch15703831.xml" TARGET="middle">Afternoon Routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch28087480.xml", "Afterschool scripting");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch28087480.xml" TARGET="middle">Afterschool scripting</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch346389042.xml", "Airplane");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch346389042.xml" TARGET="middle">Airplane</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch254584539.xml", "Alden");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch254584539.xml" TARGET="middle">Alden</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch322137202.xml", "Alden");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch322137202.xml" TARGET="middle">Alden</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch226070332.xml", "Alex and Miss Kristine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch226070332.xml" TARGET="middle">Alex and Miss Kristine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch56298390.xml", "All Numbers");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch56298390.xml" TARGET="middle">All Numbers</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch56295813.xml", "All letters");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch56295813.xml" TARGET="middle">All letters</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch56296776.xml", "All shapes");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch56296776.xml" TARGET="middle">All shapes</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch134057568.xml", "Amaya");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch134057568.xml" TARGET="middle">Amaya</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch134060521.xml", "Amaya Verbal Imitation");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch134060521.xml" TARGET="middle">Amaya Verbal Imitation</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch69198123.xml", "Animals");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch69198123.xml" TARGET="middle">Animals</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch19169218.xml", "Answering Machine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch19169218.xml" TARGET="middle">Answering Machine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch84496056.xml", "Apple Picking");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch84496056.xml" TARGET="middle">Apple Picking</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch101596969.xml", "Artifacts");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch101596969.xml" TARGET="middle">Artifacts</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch130524743.xml", "Astudent1");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch130524743.xml" TARGET="middle">Astudent1</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90984814.xml", "Bake Sugar Cookies");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90984814.xml" TARGET="middle">Bake Sugar Cookies</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch56729470.xml", "Baseball");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch56729470.xml" TARGET="middle">Baseball</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90610727.xml", "Bathroom");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90610727.xml" TARGET="middle">Bathroom</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90610690.xml", "Bedroom");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90610690.xml" TARGET="middle">Bedroom</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch15700077.xml", "Beginning Morning Routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch15700077.xml" TARGET="middle">Beginning Morning Routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch79099770.xml", "Behavior contract 01");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch79099770.xml" TARGET="middle">Behavior contract 01</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch15524096.xml", "Behavioral Contract");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch15524096.xml" TARGET="middle">Behavioral Contract</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83956271.xml", "Behaviors");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83956271.xml" TARGET="middle">Behaviors</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch39402456.xml", "Ben&#39;s Choices");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch39402456.xml" TARGET="middle">Ben&#39;s Choices</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83949893.xml", "Blocks");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83949893.xml" TARGET="middle">Blocks</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch86208568.xml", "Body Parts");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch86208568.xml" TARGET="middle">Body Parts</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch186592145.xml", "Books on tape");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch186592145.xml" TARGET="middle">Books on tape</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch15161580.xml", "Brush your teeth");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch15161580.xml" TARGET="middle">Brush your teeth</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90848854.xml", "Build a snowman");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90848854.xml" TARGET="middle">Build a snowman</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83949038.xml", "Call 9-1-1");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83949038.xml" TARGET="middle">Call 9-1-1</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83949042.xml", "Call Grandma");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83949042.xml" TARGET="middle">Call Grandma</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch84536557.xml", "Carve A Pumpkin");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch84536557.xml" TARGET="middle">Carve A Pumpkin</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch450481793.xml", "Cats");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch450481793.xml" TARGET="middle">Cats</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch140445467.xml", "Changing the sheets");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch140445467.xml" TARGET="middle">Changing the sheets</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83939150.xml", "Changing the sheets");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83939150.xml" TARGET="middle">Changing the sheets</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch102615733.xml", "Choic board classroom");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch102615733.xml" TARGET="middle">Choic board classroom</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37456341.xml", "Chores");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37456341.xml" TARGET="middle">Chores</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90974159.xml", "Christmas Tree Outing");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90974159.xml" TARGET="middle">Christmas Tree Outing</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch102686968.xml", "Class Choice Board");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch102686968.xml" TARGET="middle">Class Choice Board</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch142116346.xml", "Class Choice Board");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch142116346.xml" TARGET="middle">Class Choice Board</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch161378862.xml", "Class Choice Board");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch161378862.xml" TARGET="middle">Class Choice Board</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch102686767.xml", "Class Schedule");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch102686767.xml" TARGET="middle">Class Schedule</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17531860.xml", "Classroom Objects");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17531860.xml" TARGET="middle">Classroom Objects</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83952907.xml", "Clearing the table");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83952907.xml" TARGET="middle">Clearing the table</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17532337.xml", "Clothes");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17532337.xml" TARGET="middle">Clothes</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch69196891.xml", "Clothing");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch69196891.xml" TARGET="middle">Clothing</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch100296994.xml", "Colonial Williamsburg");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch100296994.xml" TARGET="middle">Colonial Williamsburg</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83949906.xml", "Color");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83949906.xml" TARGET="middle">Color</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch85761918.xml", "Color Words");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch85761918.xml" TARGET="middle">Color Words</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch69195547.xml", "Colors");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch69195547.xml" TARGET="middle">Colors</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17498395.xml", "Commands");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17498395.xml" TARGET="middle">Commands</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37985582.xml", "Conversation cards");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37985582.xml" TARGET="middle">Conversation cards</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch95431986.xml", "Curious george");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch95431986.xml" TARGET="middle">Curious george</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch95431987.xml", "Curious george");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch95431987.xml" TARGET="middle">Curious george</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch352818164.xml", "Dan");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch352818164.xml" TARGET="middle">Dan</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch148159071.xml", "Days of Week");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch148159071.xml" TARGET="middle">Days of Week</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90798145.xml", "Decorate Christmas Tree pics");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90798145.xml" TARGET="middle">Decorate Christmas Tree pics</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch100294024.xml", "Denison Museum");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch100294024.xml" TARGET="middle">Denison Museum</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90610701.xml", "Dining room");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90610701.xml" TARGET="middle">Dining room</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90779023.xml", "Dining room temp");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90779023.xml" TARGET="middle">Dining room temp</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch190385204.xml", "Dog test");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch190385204.xml" TARGET="middle">Dog test</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch238160904.xml", "Dog3");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch238160904.xml" TARGET="middle">Dog3</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch95341792.xml", "Dogs");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch95341792.xml" TARGET="middle">Dogs</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch238160669.xml", "Dogs2");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch238160669.xml" TARGET="middle">Dogs2</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83940667.xml", "Doing Laundry");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83940667.xml" TARGET="middle">Doing Laundry</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83941399.xml", "Doing homework");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83941399.xml" TARGET="middle">Doing homework</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch39398513.xml", "Drinks");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch39398513.xml" TARGET="middle">Drinks</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37390135.xml", "Embedded rewards");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37390135.xml" TARGET="middle">Embedded rewards</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17882238.xml", "Emotions");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17882238.xml" TARGET="middle">Emotions</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch91665820.xml", "Emotions 2");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch91665820.xml" TARGET="middle">Emotions 2</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch171232922.xml", "Energy plan 2");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch171232922.xml" TARGET="middle">Energy plan 2</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch473189747.xml", "Enter name here!");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch473189747.xml" TARGET="middle">Enter name here!</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch473295227.xml", "Enter name here!");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch473295227.xml" TARGET="middle">Enter name here!</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch32030392.xml", "Excercise routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch32030392.xml" TARGET="middle">Excercise routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch32030692.xml", "Excercise routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch32030692.xml" TARGET="middle">Excercise routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17498521.xml", "Excercises");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17498521.xml" TARGET="middle">Excercises</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch470885109.xml", "Exercise");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch470885109.xml" TARGET="middle">Exercise</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("schemotions.xml", "FM Emotions 2");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=schemotions.xml" TARGET="middle">FM Emotions 2</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17500078.xml", "Family");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17500078.xml" TARGET="middle">Family</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch69279751.xml", "Feed the dog");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch69279751.xml" TARGET="middle">Feed the dog</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83950638.xml", "Feed the dog");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83950638.xml" TARGET="middle">Feed the dog</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch69279864.xml", "Fix breakfast");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch69279864.xml" TARGET="middle">Fix breakfast</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83951296.xml", "Fix lunch");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83951296.xml" TARGET="middle">Fix lunch</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37462934.xml", "Flexible schedule");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37462934.xml" TARGET="middle">Flexible schedule</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch142432601.xml", "Flowers");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch142432601.xml" TARGET="middle">Flowers</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch85769109.xml", "Food");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch85769109.xml" TARGET="middle">Food</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch18109096.xml", "Food (breakfast)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch18109096.xml" TARGET="middle">Food (breakfast)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17263444.xml", "Food (dessert)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17263444.xml" TARGET="middle">Food (dessert)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83899845.xml", "Fruit");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83899845.xml" TARGET="middle">Fruit</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch86279428.xml", "Function of Objects");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch86279428.xml" TARGET="middle">Function of Objects</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch94149716.xml", "Function of rooms");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch94149716.xml" TARGET="middle">Function of rooms</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17499717.xml", "Furniture");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17499717.xml" TARGET="middle">Furniture</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch455924034.xml", "Gabriel and Mommy Time");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch455924034.xml" TARGET="middle">Gabriel and Mommy Time</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch12759167.xml", "Get dressed");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch12759167.xml" TARGET="middle">Get dressed</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83949020.xml", "Get dressed");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83949020.xml" TARGET="middle">Get dressed</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch15514559.xml", "Get dressed (winter)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch15514559.xml" TARGET="middle">Get dressed (winter)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83949015.xml", "Get dressed (winter)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83949015.xml" TARGET="middle">Get dressed (winter)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch16311581.xml", "Going Swimming");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch16311581.xml" TARGET="middle">Going Swimming</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch21341403.xml", "Going to gym");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch21341403.xml" TARGET="middle">Going to gym</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch18178708.xml", "Going to the amusement park");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch18178708.xml" TARGET="middle">Going to the amusement park</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch148615928.xml", "Grace After school");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch148615928.xml" TARGET="middle">Grace After school</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch114704502.xml", "Grace brush teeth");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch114704502.xml" TARGET="middle">Grace brush teeth</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch129065867.xml", "Grace menu");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch129065867.xml" TARGET="middle">Grace menu</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch122756668.xml", "Grace&#39;s Chart");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch122756668.xml" TARGET="middle">Grace&#39;s Chart</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch148605741.xml", "Grace&#39;s Chores");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch148605741.xml" TARGET="middle">Grace&#39;s Chores</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch51051144.xml", "Grace&#39;s Chores");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch51051144.xml" TARGET="middle">Grace&#39;s Chores</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch111855351.xml", "Grace&#39;s Dog List");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch111855351.xml" TARGET="middle">Grace&#39;s Dog List</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch148159171.xml", "Grace&#39;s Morning");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch148159171.xml" TARGET="middle">Grace&#39;s Morning</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch22113408.xml", "Grace&#39;s Phone Numbers");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch22113408.xml" TARGET="middle">Grace&#39;s Phone Numbers</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch9639350.xml", "Grace&#39;s Rewards");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch9639350.xml" TARGET="middle">Grace&#39;s Rewards</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch148565107.xml", "Grace&#39;s Soccer");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch148565107.xml" TARGET="middle">Grace&#39;s Soccer</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch59518561.xml", "Gracie Weekend Night  Routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch59518561.xml" TARGET="middle">Gracie Weekend Night  Routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch59348147.xml", "Gracie&#39;s Night Routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch59348147.xml" TARGET="middle">Gracie&#39;s Night Routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch78492426.xml", "Gracie&#39;s Rewards");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch78492426.xml" TARGET="middle">Gracie&#39;s Rewards</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch7824594.xml", "Grocery List");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch7824594.xml" TARGET="middle">Grocery List</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch95433209.xml", "Hannah montana");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch95433209.xml" TARGET="middle">Hannah montana</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch95433213.xml", "Hannah montana");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch95433213.xml" TARGET="middle">Hannah montana</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch84463344.xml", "Holidays");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch84463344.xml" TARGET="middle">Holidays</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17498767.xml", "House");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17498767.xml" TARGET="middle">House</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17500300.xml", "Household Objects");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17500300.xml" TARGET="middle">Household Objects</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch84473628.xml", "How to make apple pie");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch84473628.xml" TARGET="middle">How to make apple pie</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch186085225.xml", "I Need a Break");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch186085225.xml" TARGET="middle">I Need a Break</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch188573395.xml", "ILetters");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch188573395.xml" TARGET="middle">ILetters</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch97794700.xml", "In the class room");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch97794700.xml" TARGET="middle">In the class room</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch38523660.xml", "Index cards");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch38523660.xml" TARGET="middle">Index cards</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch15700158.xml", "Intermediate Morning Routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch15700158.xml" TARGET="middle">Intermediate Morning Routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch122850547.xml", "Jack&#39;s chart");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch122850547.xml" TARGET="middle">Jack&#39;s chart</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch148855952.xml", "Jake&#39;s Morning Checklist");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch148855952.xml" TARGET="middle">Jake&#39;s Morning Checklist</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch148772108.xml", "Jake&#39;s night routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch148772108.xml" TARGET="middle">Jake&#39;s night routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("schjoepecs.xml", "Joepecs");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=schjoepecs.xml" TARGET="middle">Joepecs</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90610713.xml", "Kitchen");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90610713.xml" TARGET="middle">Kitchen</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17499956.xml", "Kitchen Objects");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17499956.xml" TARGET="middle">Kitchen Objects</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch38525008.xml", "Last night at home");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch38525008.xml" TARGET="middle">Last night at home</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch18217697.xml", "Lea&#39;s Behavior Chart (Lillian Vernon)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch18217697.xml" TARGET="middle">Lea&#39;s Behavior Chart (Lillian Vernon)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch18219470.xml", "Lea&#39;s Behavior Chart (skittles)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch18219470.xml" TARGET="middle">Lea&#39;s Behavior Chart (skittles)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch122850349.xml", "Lea&#39;s Chart");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch122850349.xml" TARGET="middle">Lea&#39;s Chart</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch22191669.xml", "Lea&#39;s Dressing Schedule");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch22191669.xml" TARGET="middle">Lea&#39;s Dressing Schedule</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch149114252.xml", "Lea&#39;s Morning");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch149114252.xml" TARGET="middle">Lea&#39;s Morning</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch149114529.xml", "Lea&#39;s night routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch149114529.xml" TARGET="middle">Lea&#39;s night routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch18022460.xml", "Lea&#39;s schedule");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch18022460.xml" TARGET="middle">Lea&#39;s schedule</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch64002399.xml", "Leisure");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch64002399.xml" TARGET="middle">Leisure</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch64002491.xml", "Leisure3");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch64002491.xml" TARGET="middle">Leisure3</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch56294017.xml", "Letter 2");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch56294017.xml" TARGET="middle">Letter 2</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch56292422.xml", "Letters");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch56292422.xml" TARGET="middle">Letters</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch21341345.xml", "Library");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch21341345.xml" TARGET="middle">Library</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch207607201.xml", "Lisa Signs");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch207607201.xml" TARGET="middle">Lisa Signs</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90617618.xml", "Living Room");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90617618.xml" TARGET="middle">Living Room</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch14651521.xml", "Load the dishwasher");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch14651521.xml" TARGET="middle">Load the dishwasher</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch69032883.xml", "Lowercase Letters");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch69032883.xml" TARGET="middle">Lowercase Letters</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch16820107.xml", "Lunch");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch16820107.xml" TARGET="middle">Lunch</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37229918.xml", "Make A Schedule");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37229918.xml" TARGET="middle">Make A Schedule</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83949935.xml", "Make Chocolate Chip Cookies");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83949935.xml" TARGET="middle">Make Chocolate Chip Cookies</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37882645.xml", "Make a Phone Call");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37882645.xml" TARGET="middle">Make a Phone Call</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83949944.xml", "Make a milkshake");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83949944.xml" TARGET="middle">Make a milkshake</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83949938.xml", "Make a peanut butter and jelly sandwhich");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83949938.xml" TARGET="middle">Make a peanut butter and jelly sandwhich</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90986231.xml", "Make a snowman");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90986231.xml" TARGET="middle">Make a snowman</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83949929.xml", "Make a sundae");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83949929.xml" TARGET="middle">Make a sundae</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83950559.xml", "Make your bed");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83950559.xml" TARGET="middle">Make your bed</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90849940.xml", "Making Sugar Cookies pics");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90849940.xml" TARGET="middle">Making Sugar Cookies pics</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch455923567.xml", "Matthew and Mommy Time");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch455923567.xml" TARGET="middle">Matthew and Mommy Time</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17757772.xml", "Missing food");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17757772.xml" TARGET="middle">Missing food</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37882919.xml", "Monday&#39;s checklist");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37882919.xml" TARGET="middle">Monday&#39;s checklist</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch123542212.xml", "Monkeys");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch123542212.xml" TARGET="middle">Monkeys</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch86733601.xml", "More shapes");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch86733601.xml" TARGET="middle">More shapes</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch260709860.xml", "Moring 02");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch260709860.xml" TARGET="middle">Moring 02</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch173788.xml", "Morning");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch173788.xml" TARGET="middle">Morning</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch51981709.xml", "Morning Routine Schedules");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch51981709.xml" TARGET="middle">Morning Routine Schedules</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch154292684.xml", "Morning Routine with reward");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch154292684.xml" TARGET="middle">Morning Routine with reward</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch161894357.xml", "Morning routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch161894357.xml" TARGET="middle">Morning routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch26406913.xml", "Morning routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch26406913.xml" TARGET="middle">Morning routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch104774158.xml", "Muscle Man");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch104774158.xml" TARGET="middle">Muscle Man</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17500439.xml", "Musical Instruments");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17500439.xml" TARGET="middle">Musical Instruments</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch14413946.xml", "My Morning Routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch14413946.xml" TARGET="middle">My Morning Routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch259950813.xml", "My Trip To the NC");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch259950813.xml" TARGET="middle">My Trip To the NC</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch144979336.xml", "My rewards");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch144979336.xml" TARGET="middle">My rewards</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch49852328.xml", "Mychores");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch49852328.xml" TARGET="middle">Mychores</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90973034.xml", "New Year&#39;s Eve");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90973034.xml" TARGET="middle">New Year&#39;s Eve</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90970924.xml", "New Year&#39;s Eve pics");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90970924.xml" TARGET="middle">New Year&#39;s Eve pics</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch101434646.xml", "New friends");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch101434646.xml" TARGET="middle">New friends</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37925133.xml", "Night Routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37925133.xml" TARGET="middle">Night Routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch85762082.xml", "Number Words");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch85762082.xml" TARGET="middle">Number Words</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch86300557.xml", "Numbers");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch86300557.xml" TARGET="middle">Numbers</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch56298100.xml", "Numbers 1");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch56298100.xml" TARGET="middle">Numbers 1</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch56298358.xml", "Numbers 2");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch56298358.xml" TARGET="middle">Numbers 2</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch91487629.xml", "Occupations");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch91487629.xml" TARGET="middle">Occupations</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83936419.xml", "Occupations pics");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83936419.xml" TARGET="middle">Occupations pics</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch32027761.xml", "Old Actions");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch32027761.xml" TARGET="middle">Old Actions</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch115515963.xml", "One year subscription to www.joeschedule.com");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch115515963.xml" TARGET="middle">One year subscription to www.joeschedule.com</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch24752394.xml", "Outside Choices");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch24752394.xml" TARGET="middle">Outside Choices</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83941219.xml", "Packing bag for school");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83941219.xml" TARGET="middle">Packing bag for school</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch27372353.xml", "Paying attention in class");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch27372353.xml" TARGET="middle">Paying attention in class</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch133997578.xml", "Pecs");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch133997578.xml" TARGET="middle">Pecs</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch85763035.xml", "Pics Months of the Year");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch85763035.xml" TARGET="middle">Pics Months of the Year</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17596606.xml", "Picture sites");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17596606.xml" TARGET="middle">Picture sites</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch85866359.xml", "Pictures");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch85866359.xml" TARGET="middle">Pictures</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch42601259.xml", "Pix(1) Demo");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch42601259.xml" TARGET="middle">Pix(1) Demo</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch31766010.xml", "Places to gO");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch31766010.xml" TARGET="middle">Places to gO</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch14570674.xml", "Plant flowers");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch14570674.xml" TARGET="middle">Plant flowers</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch22186967.xml", "Planting bulbs");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch22186967.xml" TARGET="middle">Planting bulbs</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch24753180.xml", "Play Inside");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch24753180.xml" TARGET="middle">Play Inside</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch12009935.xml", "Play T-Ball");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch12009935.xml" TARGET="middle">Play T-Ball</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch14570736.xml", "Play doctor");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch14570736.xml" TARGET="middle">Play doctor</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch41511088.xml", "Play house");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch41511088.xml" TARGET="middle">Play house</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch14570723.xml", "Play store");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch14570723.xml" TARGET="middle">Play store</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch226070106.xml", "Preview");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch226070106.xml" TARGET="middle">Preview</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch85269148.xml", "Pumpkin Picking");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch85269148.xml" TARGET="middle">Pumpkin Picking</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch95347269.xml", "Puppies");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch95347269.xml" TARGET="middle">Puppies</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83949898.xml", "Puzzle");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83949898.xml" TARGET="middle">Puzzle</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch85763831.xml", "Questions");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch85763831.xml" TARGET="middle">Questions</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch50956760.xml", "RDI schedule");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch50956760.xml" TARGET="middle">RDI schedule</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch84496335.xml", "Raking Leaves");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch84496335.xml" TARGET="middle">Raking Leaves</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch47172310.xml", "Rdi(z:\)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch47172310.xml" TARGET="middle">Rdi(z:\)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch69194737.xml", "Red");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch69194737.xml" TARGET="middle">Red</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37391165.xml", "Reinforcers");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37391165.xml" TARGET="middle">Reinforcers</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37390775.xml", "Reward at end");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37390775.xml" TARGET="middle">Reward at end</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90614084.xml", "Rooms");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90614084.xml" TARGET="middle">Rooms</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch91202391.xml", "Rooms pics");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch91202391.xml" TARGET="middle">Rooms pics</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83887916.xml", "Rooms2");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83887916.xml" TARGET="middle">Rooms2</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch70030756.xml", "Rule");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch70030756.xml" TARGET="middle">Rule</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch4716740.xml", "Rules 2");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch4716740.xml" TARGET="middle">Rules 2</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch40302686.xml", "Saturday");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch40302686.xml" TARGET="middle">Saturday</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch23374977.xml", "Saturday Activities");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch23374977.xml" TARGET="middle">Saturday Activities</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch85269377.xml", "Save pumpkin pics");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch85269377.xml" TARGET="middle">Save pumpkin pics</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch15699509.xml", "Schedules Of The Month");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch15699509.xml" TARGET="middle">Schedules Of The Month</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch42426252.xml", "Science");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch42426252.xml" TARGET="middle">Science</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch84463768.xml", "Season");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch84463768.xml" TARGET="middle">Season</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch18108057.xml", "Seasons (Fall)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch18108057.xml" TARGET="middle">Seasons (Fall)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch22186881.xml", "September Schedules");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch22186881.xml" TARGET="middle">September Schedules</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch84028307.xml", "Shapes");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch84028307.xml" TARGET="middle">Shapes</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch56296567.xml", "Shapes 1");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch56296567.xml" TARGET="middle">Shapes 1</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch56296732.xml", "Shapes 2");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch56296732.xml" TARGET="middle">Shapes 2</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch23653125.xml", "Shark vocabulary");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch23653125.xml" TARGET="middle">Shark vocabulary</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch40225875.xml", "Sign language");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch40225875.xml" TARGET="middle">Sign language</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37545566.xml", "Skills checklist");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37545566.xml" TARGET="middle">Skills checklist</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch32370633.xml", "Snacks");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch32370633.xml" TARGET="middle">Snacks</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch28315835.xml", "Social skills website");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch28315835.xml" TARGET="middle">Social skills website</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch95346584.xml", "Sonic");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch95346584.xml" TARGET="middle">Sonic</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch133726345.xml", "Spitting");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch133726345.xml" TARGET="middle">Spitting</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17337302.xml", "Sports");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17337302.xml" TARGET="middle">Sports</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch85777318.xml", "Sports temp");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch85777318.xml" TARGET="middle">Sports temp</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch325261550.xml", "Spring Planting");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch325261550.xml" TARGET="middle">Spring Planting</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17532167.xml", "Stationery");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17532167.xml" TARGET="middle">Stationery</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch134061019.xml", "Stephanie");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch134061019.xml" TARGET="middle">Stephanie</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch16567950.xml", "Steps for Daily Routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch16567950.xml" TARGET="middle">Steps for Daily Routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch15162879.xml", "String beads");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch15162879.xml" TARGET="middle">String beads</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("Students.xml", "Students");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=Students.xml" TARGET="middle">Students</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17532755.xml", "Summer");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17532755.xml" TARGET="middle">Summer</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83950644.xml", "Sweeping");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83950644.xml" TARGET="middle">Sweeping</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch70838943.xml", "Table Time");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch70838943.xml" TARGET="middle">Table Time</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch70838701.xml", "Table time");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch70838701.xml" TARGET="middle">Table time</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch14570318.xml", "Take a bath");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch14570318.xml" TARGET="middle">Take a bath</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch14570466.xml", "Take a shower");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch14570466.xml" TARGET="middle">Take a shower</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch154484247.xml", "Temp");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch154484247.xml" TARGET="middle">Temp</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch110813199.xml", "Test");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch110813199.xml" TARGET="middle">Test</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch86399677.xml", "Test");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch86399677.xml" TARGET="middle">Test</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("schMyComBoard01.xml", "The Com Board");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=schMyComBoard01.xml" TARGET="middle">The Com Board</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch171142680.xml", "The Mastonardi Energy Plan");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch171142680.xml" TARGET="middle">The Mastonardi Energy Plan</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch42652637.xml", "Thomas");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch42652637.xml" TARGET="middle">Thomas</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch49904366.xml", "Time with Dad");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch49904366.xml" TARGET="middle">Time with Dad</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch49905245.xml", "Time with Mom");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch49905245.xml" TARGET="middle">Time with Mom</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch15704716.xml", "Today at school");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch15704716.xml" TARGET="middle">Today at school</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch31956549.xml", "Token Exchange Board");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch31956549.xml" TARGET="middle">Token Exchange Board</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch67355195.xml", "Top");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch67355195.xml" TARGET="middle">Top</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch133726533.xml", "Touching face");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch133726533.xml" TARGET="middle">Touching face</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch133726535.xml", "Touching face");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch133726535.xml" TARGET="middle">Touching face</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17347078.xml", "Toys");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17347078.xml" TARGET="middle">Toys</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83949889.xml", "Trains");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83949889.xml" TARGET="middle">Trains</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37479374.xml", "Trampoline Jumping");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37479374.xml" TARGET="middle">Trampoline Jumping</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch32025465.xml", "Transition example 1");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch32025465.xml" TARGET="middle">Transition example 1</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch32025847.xml", "Transition example 2");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch32025847.xml" TARGET="middle">Transition example 2</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch32026006.xml", "Transition example 3");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch32026006.xml" TARGET="middle">Transition example 3</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37728005.xml", "Transition example 3a");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37728005.xml" TARGET="middle">Transition example 3a</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch32026384.xml", "Transition example 4");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch32026384.xml" TARGET="middle">Transition example 4</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch32026537.xml", "Transition example 5");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch32026537.xml" TARGET="middle">Transition example 5</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch32027642.xml", "Transition example 6");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch32027642.xml" TARGET="middle">Transition example 6</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch17500475.xml", "Transportation");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch17500475.xml" TARGET="middle">Transportation</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch84466818.xml", "Trick or Treating");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch84466818.xml" TARGET="middle">Trick or Treating</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch37883234.xml", "Tuesday&#39;s checklist");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch37883234.xml" TARGET="middle">Tuesday&#39;s checklist</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch148164288.xml", "Tyler AfterSchool");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch148164288.xml" TARGET="middle">Tyler AfterSchool</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch164901279.xml", "Tyler Articulation");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch164901279.xml" TARGET="middle">Tyler Articulation</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch148561417.xml", "Tyler Baseball Checklist");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch148561417.xml" TARGET="middle">Tyler Baseball Checklist</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch43413017.xml", "Tyler Breakfast");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch43413017.xml" TARGET="middle">Tyler Breakfast</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch59356917.xml", "Tyler Morning Routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch59356917.xml" TARGET="middle">Tyler Morning Routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch122766740.xml", "Tyler&#39;s Chart");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch122766740.xml" TARGET="middle">Tyler&#39;s Chart</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch59348738.xml", "Tyler&#39;s Night  Routine");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch59348738.xml" TARGET="middle">Tyler&#39;s Night  Routine</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch148607039.xml", "Tyler&#39;s chores");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch148607039.xml" TARGET="middle">Tyler&#39;s chores</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch148614369.xml", "Tyler&#39;s night");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch148614369.xml" TARGET="middle">Tyler&#39;s night</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch101813077.xml", "Tyler&#39;s pet");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch101813077.xml" TARGET="middle">Tyler&#39;s pet</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch85779146.xml", "Upper/Lower Case Letters");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch85779146.xml" TARGET="middle">Upper/Lower Case Letters</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch86294727.xml", "Uppercase letters");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch86294727.xml" TARGET="middle">Uppercase letters</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83899905.xml", "Vegetables");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83899905.xml" TARGET="middle">Vegetables</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch84030383.xml", "Vehicles");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch84030383.xml" TARGET="middle">Vehicles</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch130524621.xml", "Verbal Imitation");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch130524621.xml" TARGET="middle">Verbal Imitation</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch42599295.xml", "Verbs");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch42599295.xml" TARGET="middle">Verbs</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch152801457.xml", "WH");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch152801457.xml" TARGET="middle">WH</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83948992.xml", "Washing hands");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83948992.xml" TARGET="middle">Washing hands</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83948996.xml", "Washing hands (boy)");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83948996.xml" TARGET="middle">Washing hands (boy)</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch99607554.xml", "Webkins");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch99607554.xml" TARGET="middle">Webkins</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch99690681.xml", "Webkins 2");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch99690681.xml" TARGET="middle">Webkins 2</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch238100005.xml", "Welcome");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch238100005.xml" TARGET="middle">Welcome</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch38517289.xml", "Wh questions");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch38517289.xml" TARGET="middle">Wh questions</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch164922847.xml", "What Season");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch164922847.xml" TARGET="middle">What Season</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch85762230.xml", "What are the days of the week?");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch85762230.xml" TARGET="middle">What are the days of the week?</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch85764881.xml", "What are the months of the year?");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch85764881.xml" TARGET="middle">What are the months of the year?</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83887104.xml", "What do you ____ with?");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83887104.xml" TARGET="middle">What do you ____ with?</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch53000408.xml", "What do you eat with?");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch53000408.xml" TARGET="middle">What do you eat with?</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch164922450.xml", "What is he/she doing");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch164922450.xml" TARGET="middle">What is he/she doing</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch94140724.xml", "What takes you to school");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch94140724.xml" TARGET="middle">What takes you to school</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch52999511.xml", "What takes you to school?");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch52999511.xml" TARGET="middle">What takes you to school?</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83899759.xml", "What&#39;s This");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83899759.xml" TARGET="middle">What&#39;s This</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch83899088.xml", "What&#39;s this categories");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch83899088.xml" TARGET="middle">What&#39;s this categories</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch94149461.xml", "When");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch94149461.xml" TARGET="middle">When</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch16926045.xml", "Where Questions");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch16926045.xml" TARGET="middle">Where Questions</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch94140533.xml", "Which one");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch94140533.xml" TARGET="middle">Which one</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch16990962.xml", "Who Questions?");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch16990962.xml" TARGET="middle">Who Questions?</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90985323.xml", "Winter Activities");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90985323.xml" TARGET="middle">Winter Activities</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90981120.xml", "Winter Objects");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90981120.xml" TARGET="middle">Winter Objects</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90880901.xml", "Winter objects pics");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90880901.xml" TARGET="middle">Winter objects pics</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch90879390.xml", "Winter things to do pics");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch90879390.xml" TARGET="middle">Winter things to do pics</A>
<br>
</Schedule>
<Schedule>
  <input type="radio" name="C1" onclick = 'notifytop("sch91482688.xml", "Yard");' /> 
  <A HREF="/cgi-bin/cgi/ngfop/sch3b.pl?htmlname=sch3b.htm&name=sch91482688.xml" TARGET="middle">Yard</A>
<br>
</Schedule>


<font size="2" color="#FF0000"><b><i>My Choice Boards</i></b></font>

<br>



<input type="radio" name="C1" onclick = 'notifytop("cb93622430.xml", "00 My Portfolio");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb93622430.xml&htmlname=cb3a.htm" TARGET="middle">00 My Portfolio</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb126536133.xml", "00 School for the Deaf Labels");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb126536133.xml&htmlname=cb3a.htm" TARGET="middle">00 School for the Deaf Labels</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb461296449.xml", "000");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb461296449.xml&htmlname=cb3a.htm" TARGET="middle">000</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb142250214.xml", "000 Class Schedule loca");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb142250214.xml&htmlname=cb3a.htm" TARGET="middle">000 Class Schedule loca</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb122170446.xml", "000 Violin Practice");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb122170446.xml&htmlname=cb3a.htm" TARGET="middle">000 Violin Practice</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb259190930.xml", "000 mypics");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb259190930.xml&htmlname=cb3a.htm" TARGET="middle">000 mypics</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb54205042.xml", "0001b");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb54205042.xml&htmlname=cb3a.htm" TARGET="middle">0001b</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb474201936.xml", "000local");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb474201936.xml&htmlname=cb3a.htm" TARGET="middle">000local</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb22442127.xml", "00Augmentive Devices");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb22442127.xml&htmlname=cb3a.htm" TARGET="middle">00Augmentive Devices</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb91706449.xml", "00ret labels");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb91706449.xml&htmlname=cb3a.htm" TARGET="middle">00ret labels</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb276658152.xml", "0Dogs");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb276658152.xml&htmlname=cb3a.htm" TARGET="middle">0Dogs</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb87070570.xml", "10-10-06 Hay Ride(1-13)");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb87070570.xml&htmlname=cb3a.htm" TARGET="middle">10-10-06 Hay Ride(1-13)</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb87070998.xml", "10-10-06 Hay Ride(13-21)");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb87070998.xml&htmlname=cb3a.htm" TARGET="middle">10-10-06 Hay Ride(13-21)</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb87071067.xml", "10-10-06 Hay Ride(22-28)");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb87071067.xml&htmlname=cb3a.htm" TARGET="middle">10-10-06 Hay Ride(22-28)</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb211286349.xml", "Activities");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb211286349.xml&htmlname=cb3a.htm" TARGET="middle">Activities</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb24718221.xml", "After school snacks");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb24718221.xml&htmlname=cb3a.htm" TARGET="middle">After school snacks</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb224161371.xml", "Alex and Miss Kristine");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb224161371.xml&htmlname=cb3a.htm" TARGET="middle">Alex and Miss Kristine</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cbboardgame.xml", "Board games.");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cbboardgame.xml&htmlname=cb3a.htm" TARGET="middle">Board games.</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb39385848.xml", "Breakfast");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb39385848.xml&htmlname=cb3a.htm" TARGET="middle">Breakfast</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb37462998.xml", "Choice");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb37462998.xml&htmlname=cb3a.htm" TARGET="middle">Choice</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb37465015.xml", "Choice2");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb37465015.xml&htmlname=cb3a.htm" TARGET="middle">Choice2</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb37464833.xml", "Choice3");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb37464833.xml&htmlname=cb3a.htm" TARGET="middle">Choice3</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb73779510.xml", "Chore card");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb73779510.xml&htmlname=cb3a.htm" TARGET="middle">Chore card</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb37456530.xml", "Chores");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb37456530.xml&htmlname=cb3a.htm" TARGET="middle">Chores</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cbcolors.xml", "Colors");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cbcolors.xml&htmlname=cb3a.htm" TARGET="middle">Colors</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb24763529.xml", "Convo cards");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb24763529.xml&htmlname=cb3a.htm" TARGET="middle">Convo cards</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb176341792.xml", "Enter name here!");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb176341792.xml&htmlname=cb3a.htm" TARGET="middle">Enter name here!</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb473302375.xml", "Enter name here!");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb473302375.xml&htmlname=cb3a.htm" TARGET="middle">Enter name here!</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cbexer.xml", "Exercise");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cbexer.xml&htmlname=cb3a.htm" TARGET="middle">Exercise</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cbff.xml", "Fast food");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cbff.xml&htmlname=cb3a.htm" TARGET="middle">Fast food</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb37728045.xml", "Free play");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb37728045.xml&htmlname=cb3a.htm" TARGET="middle">Free play</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb39385899.xml", "Fruit");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb39385899.xml&htmlname=cb3a.htm" TARGET="middle">Fruit</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb74769058.xml", "Get dressed");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb74769058.xml&htmlname=cb3a.htm" TARGET="middle">Get dressed</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb112233.xml", "Going to the dentist");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb112233.xml&htmlname=cb3a.htm" TARGET="middle">Going to the dentist</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb55206000.xml", "House schedule");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb55206000.xml&htmlname=cb3a.htm" TARGET="middle">House schedule</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb67501399.xml", "In the classroom");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb67501399.xml&htmlname=cb3a.htm" TARGET="middle">In the classroom</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb78487926.xml", "Jakes choices");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb78487926.xml&htmlname=cb3a.htm" TARGET="middle">Jakes choices</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb235572020.xml", "Joemailweb");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb235572020.xml&htmlname=cb3a.htm" TARGET="middle">Joemailweb</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb20705678.xml", "Joeschedule Handheld");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb20705678.xml&htmlname=cb3a.htm" TARGET="middle">Joeschedule Handheld</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb85920952.xml", "Limba letters");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb85920952.xml&htmlname=cb3a.htm" TARGET="middle">Limba letters</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb252779902.xml", "Make a sundae");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb252779902.xml&htmlname=cb3a.htm" TARGET="middle">Make a sundae</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb186975265.xml", "Morning routine");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb186975265.xml&htmlname=cb3a.htm" TARGET="middle">Morning routine</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cbmusic.xml", "Music");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cbmusic.xml&htmlname=cb3a.htm" TARGET="middle">Music</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb42603638.xml", "Occupations");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb42603638.xml&htmlname=cb3a.htm" TARGET="middle">Occupations</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb85920069.xml", "One");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb85920069.xml&htmlname=cb3a.htm" TARGET="middle">One</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb50886376.xml", "Photo Album(comcast)");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb50886376.xml&htmlname=cb3a.htm" TARGET="middle">Photo Album(comcast)</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb60876916.xml", "Pics");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb60876916.xml&htmlname=cb3a.htm" TARGET="middle">Pics</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb24753286.xml", "Play");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb24753286.xml&htmlname=cb3a.htm" TARGET="middle">Play</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb24752535.xml", "Play Outside");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb24752535.xml&htmlname=cb3a.htm" TARGET="middle">Play Outside</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb42826428.xml", "Project Plan");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb42826428.xml&htmlname=cb3a.htm" TARGET="middle">Project Plan</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb27738523.xml", "Raising hand<br> pay attention");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb27738523.xml&htmlname=cb3a.htm" TARGET="middle">Raising hand<br> pay attention</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb37921659.xml", "Snacks");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb37921659.xml&htmlname=cb3a.htm" TARGET="middle">Snacks</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb177346562.xml", "Test");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb177346562.xml&htmlname=cb3a.htm" TARGET="middle">Test</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb58662770.xml", "The Practice List!");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb58662770.xml&htmlname=cb3a.htm" TARGET="middle">The Practice List!</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb112961315.xml", "Total Recall");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb112961315.xml&htmlname=cb3a.htm" TARGET="middle">Total Recall</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb70025181.xml", "Try this URL in pictures");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb70025181.xml&htmlname=cb3a.htm" TARGET="middle">Try this URL in pictures</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb85920088.xml", "Two");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb85920088.xml&htmlname=cb3a.htm" TARGET="middle">Two</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb91417462.xml", "Wh questions");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb91417462.xml&htmlname=cb3a.htm" TARGET="middle">Wh questions</a>
  <br><input type="radio" name="C1" onclick = 'notifytop("cb450624387.xml", "Xxxxx");' />
  <a HREF="/cgi-bin/cgi/ngfop/sch3.pl?name=cb450624387.xml&htmlname=cb3a.htm" TARGET="middle">Xxxxx</a>
  <br>   

<hr></hr>

<font size="2" color="#FF0000"><b><i>Classroom</i></b></font>



<br>

  <input type="radio" name="C1" onclick = "notifytop('schs/schlettersuc.xml', 'the description');">

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=schlettersuc.xml&htmlname=cb3a.htm" TARGET="middle">Letters 

upper-case</A>



<br>

  <input type="radio" name="C1" onclick = "notifytop('schs/sch102686767.xml', 'the description');"> 

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch102686767.xml&htmlname=cb3a.htm" TARGET="middle">Class Schedule</A>

<br>



  <input type="radio" name="C1" onclick = "notifytop('schs/sch102686968.xml', 'the description');"> 

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch102686968.xml&htmlname=cb3a.htm" TARGET="middle">Class Choice Board</A>

<br>



  <input type="radio" name="C1" onclick = "notifytop('schs/sch15704716.xml', 'the description');"> 

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch15704716.xml&htmlname=cb3a.htm" TARGET="middle">School Communication Forms</A>

<br>



  <input type="radio" name="C1" onclick = "notifytop('schs/sch97178354.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch97178354.xml&htmlname=cb3a.htm" TARGET="middle">Social questions</A>



<br>



<font size="2" color="#FF0000"><b><i>Chores</i></b></font>



<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12875936.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12875936.xml&htmlname=cb3a.htm" TARGET="middle">Changing the sheets</A>



<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch13217963.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch13217963.xml&htmlname=cb3a.htm" TARGET="middle">Doing laundry</A>



<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12847280.xml', 'the description');"> 

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12847280.xml&htmlname=cb3a.htm" TARGET="middle">Make your bed</A>

<br>

   

  <input type="radio"  name="C1" onclick = "notifytop('schs/sch14650544.xml', 'the description');"> 

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch14650544.xml&htmlname=cb3a.htm" TARGET="middle">Clearing the table</A>

<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12962084.xml', 'the description');">      

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12962084.xml&htmlname=cb3a.htm" TARGET="middle">Sweeping</A>

<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12849374.xml', 'the description');"> 

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12849374.xml&htmlname=cb3a.htm" TARGET="middle">Feed the dog</A>

<br>



<font size="2" color="#FF0000"><b><i>Bathroom</i></b></font>

<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12651741.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12651741.xml&htmlname=cb3a.htm" TARGET="middle">Wash your hair</A>



<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12692642.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12692642.xml&htmlname=cb3a.htm" TARGET="middle">Washing hands</A>



<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch15488083.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch15488083.xml&htmlname=cb3a.htm" TARGET="middle">Washing hands(boy)</A>



<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch15429316.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch15429316.xml&htmlname=cb3a.htm" TARGET="middle">Go to the bathroom</A>



<br>







<font size="2" color="#FF0000"><b><i>Home Skills</i></b></font>

<br>

  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12759921.xml', 'the description');"> 

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12759921.xml&htmlname=cb3a.htm" TARGET="middle">Call 9-1-1</A>

<br>

  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12760440.xml', 'the description');"> 

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12760440.xml&htmlname=cb3a.htm" TARGET="middle">Call Grandma</A>

<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12960307.xml', 'the description');"> 

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12960307.xml&htmlname=cb3a.htm" TARGET="middle">Fix breakfast</A>

<br>

  <input type="radio"  name="C1" onclick = "notifytop('schs/sch14570579.xml', 'the description');"> 

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch14570579.xml&htmlname=cb3a.htm" TARGET="middle">Fix lunch</A>

   

<br>

  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12759167.xml', 'the description');"> 

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12759167.xml&htmlname=cb3a.htm" TARGET="middle">Get dressed</A>

<br>

  <input type="radio"  name="C1" onclick = "notifytop('schs/sch15514559.xml', 'the description');"> 

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch15514559.xml&htmlname=cb3a.htm" TARGET="middle">Get dressed (winter)</A>

<br>



   

<font size="2" color="#FF0000"><b><i>Play Skills</i></b></font>

<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch13002058.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch13002058.xml&htmlname=cb3a.htm" TARGET="middle">Trains</A>



<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch13001859.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch13001859.xml&htmlname=cb3a.htm" TARGET="middle">Blocks</A>



<br>







  <input type="radio"  name="C1" onclick = "notifytop('schs/sch13001792.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch13001792.xml&htmlname=cb3a.htm" TARGET="middle">Puzzle</A>



<br>







  <input type="radio"  name="C1" onclick = "notifytop('schs/sch13001677.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch13001677.xml&htmlname=cb3a.htm" TARGET="middle">Play house</A>



<br>







  <input type="radio"  name="C1" onclick = "notifytop('schs/sch15167474.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch15167474.xml&htmlname=cb3a.htm" TARGET="middle">Color</A>



<br>



  













<font size="2" color="#FF0000"><b><i>Recipes</i></b></font>



<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch13084897.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch13084897.xml&htmlname=cb3a.htm" TARGET="middle">Make a sundae</A>



<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12686642.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12686642.xml&htmlname=cb3a.htm" TARGET="middle">Make Chocolate Chip Cookies</A>



<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12008232.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12008232.xml&htmlname=cb3a.htm" TARGET="middle">Make a peanut butter and jelly sandwhich</A>



<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch14569362.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch14569362.xml&htmlname=cb3a.htm" TARGET="middle">Make a milkshake</A>



<br>













<font size="2" color="#FF0000"><b><i>Routine</i></b></font>



<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12960175.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12960175.xml&htmlname=cb3a.htm" TARGET="middle">Morning routine</A>



<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12960076.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12960076.xml&htmlname=cb3a.htm" TARGET="middle">Night time routine</A>



<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12865762.xml', 'the description');"> 

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12865762.xml&htmlname=cb3a.htm" TARGET="middle">Packing bag for school</A>

<br>



  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12921224.xml', 'the description');"> 



  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12921224.xml&htmlname=cb3a.htm" TARGET="middle">Hang up coat</A>



<br>

  <input type="radio"  name="C1" onclick = "notifytop('schs/sch12848803.xml', 'the description');"> 

  <A HREF="/cgi-bin/cgi/ngfop/pubschs.pl?name=sch12848803.xml&htmlname=cb3a.htm" TARGET="middle">Doing homework</A>

<br>

   

</form>
`);
}
}