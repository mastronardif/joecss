Joeschedule css
==================
2019-02-02


A joeschedule version 2.0: https, css grids, nodejs.
Replaced: Perl, html framesets, and removed some functionality that was comlicted and not used much.



Features
------------
- Make picture schedules.
- one liner
- onDrag and onStop callbacks

